/**
 * Created by jt on 2018-12-07.
 */
public class HelloWorldTest {

    public void testHello(){

        System.out.println("TEST - Hello...");
    }

    public void testWorld() {
        System.out.println("TEST - World!!!!");
    }

}
